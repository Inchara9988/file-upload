import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TeacherService {
  url:string='http://localhost:8081/teacher/';
  constructor(private http:HttpClient) { }
  
  getAllTeacher()
  {
    return this.http.get(this.url);
  }
  findTeacherById(id:number)
  {
    alert("service findbyid" +id );
    
    return this.http.get(this.url+id);
    
  }
  addTeacher(teacher:any)
  {
    return this.http.post(this.url,teacher);
  }
  updateTeacher(teacher:any)
  {
    return this.http.put(this.url,teacher);
  }
  deleteTeacher(id:number)
  {
    return this.http.delete(this.url+id);
  }
}
