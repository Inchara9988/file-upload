import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FileuploadService } from '../fileupload.service';

@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css']
})
export class FileuploadComponent implements OnInit {
lectureForm:any;
lecture:any;
title = 'image-upload';
selectedFile: any;
retrievedImage: any;
base64Data: any;
retrieveResonse: any;
message: any;
imageName: any;
idL:any;
nameL:any;
typeL:any;
    //   chapter:['']
  constructor(private ls:FileuploadService, private fb:FormBuilder) { 
    
    this.lectureForm=this.fb.group({
      idL:[''],
      nameL:[''],
      typeL:[''],
      chapter:['']

    });
  }
  

  ngOnInit(): void {
  }

  
  fnFindLecture(){
   
    var idL=this.lectureForm.controls.idL.value;
    alert(idL);
    this.ls.findLectureById(idL).subscribe(data=>{
      alert(data);
      if(data==null)
        return;
      this.lecture=data;      
      this.lectureForm.patchValue(this.lecture);
    });
  }

  // fnUpload(){
  //   this.fnAddLecture();
  //   this.onUpload();
  // }

  onFileChanged(event:any)
  {
    this.selectedFile=event.target.files[0];
    console.log(JSON.stringify(this.selectedFile));
  }
  onUpload()
  {
    // console.log(this.selectedFile);
    
    // //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
    // var uploadImageData = new FormData();
    // uploadImageData.append('pic', this.selectedFile, this.selectedFile.name);
    // console.log(uploadImageData);

    // // this.ls.sendImage(this.selectedFile).subscribe(data=>console.log(data));
    // this.ls.sendImage(uploadImageData).subscribe(data=>console.log(data));
    var formData=new FormData();
 
  //  formData.append('pic',this.selectedFile,this.selectedFile.name);
  // formData.append('name','Jag');     formData.append('courseId',chapter.courseid);
  formData.append("idL", this.lectureForm.get('idL').value);
  formData.append("nameL", this.lectureForm.get('nameL').value);
    formData.append('typeL',this.selectedFile,this.selectedFile.name);


   alert(formData);
 this.ls.addLecture(formData).subscribe(data=>console.log(data));
  }
  
  fnAddLecture()
  {
    var lecture=this.lectureForm.value;
    this.ls.addLecture(lecture).subscribe(data=>console.log(data));
  }
  fnUpdateLecture()
  {
    var lecture=this.lectureForm.value;
    this.ls.updateLecture(lecture).subscribe(data=>console.log(data));
  }
  fnDeleteLecture()
  {
    var id=this.lectureForm.controls.id.value;
    this.ls.deleteLecture(id).subscribe(data=>console.log(data));
  }

}
