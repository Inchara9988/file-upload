import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FileuploadService {

  constructor(private http:HttpClient) { }
   
  picUpload(pic:any){
     return this.http.post('http://localhost:8081/lecture/t/',pic);
  }



  getAllLecture(){
    return this.http.get('http://localhost:8081/lecture/');
  }
  findLectureById(idL:number)
  {
    alert("service findbyid" +idL );
    
    return this.http.get('http://localhost:8081/lecture/'+idL);
    
  }

  addLecture(lecture:any)
  {
    return this.http.post('http://localhost:8081/lecture/',lecture);
  }

  updateLecture(lecture:any)
  {
    return this.http.put('http://localhost:8081/lecture/',lecture);
  }
  deleteLecture(idL:number)
  {
    return this.http.delete('http://localhost:8081/lecture/'+idL);
  }

}
