import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LectureService {

  url:string='http://localhost:8081/chapter/';
  // :String='http://localhost:8081/lecture/';

  constructor(private http:HttpClient) { }

  getAllLecture(){
    return this.http.get('http://localhost:8081/lecture/');
  }
  findLectureById(idL:number)
  {
    alert("service findbyid" +idL );
    
    return this.http.get('http://localhost:8081/lecture/'+idL);
    
  }

  addLecture(lecture:any)
  {
    return this.http.post('http://localhost:8081/lecture/',lecture);
  }

  updateLecture(lecture:any)
  {
    return this.http.put('http://localhost:8081/lecture/',lecture);
  }
  deleteLecture(idL:number)
  {
    return this.http.delete('http://localhost:8081/lecture/'+idL);
  }

  // ----------------------------------------------------------------------------------------------------------------

  getAllChapter()
  {
    return this.http.get(this.url);
  }
  findChapterById(id:number)
  {
    alert("service findbyid" +id );
    
    return this.http.get(this.url+id);
    
  }
  addChapter(chpater:any)
  {
    return this.http.post(this.url,chpater);
  }
  updateChapter(chpater:any)
  {
    return this.http.put(this.url,chpater);
  }
  deleteChapter(id:number)
  {
    return this.http.delete(this.url+id);
  }
}
