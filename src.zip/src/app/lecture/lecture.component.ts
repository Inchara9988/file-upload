import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { LectureService } from '../lecture.service';


@Component({
  selector: 'app-lecture',
  templateUrl: './lecture.component.html',
  styleUrls: ['./lecture.component.css']
})
export class LectureComponent implements OnInit {

  chapterForm:any;
  lectureForm:any;
  chapter:any;
  lecture:any;
title = 'image-upload';
selectedFile: any;
retrievedImage: any;
base64Data: any;
retrieveResonse: any;
message: any;
imageName: any;
idL:any;
nameL:any;
typeL:any;
  constructor(private cs:LectureService, private fb:FormBuilder) { 
    this.chapterForm=this.fb.group({
      // id:[''],
      // firstName:[''],
      // lastName:[''],
      // email:[''],
      // qualification:[''],
      // password:[''],
      // confirmPassword:[''],
      // mobileNuber:['']
      id:[''],
      name:[''],
      lecture:[''],
      // idL:[''],
      // nameL:[''],
      // typeL:[''],
      // chapter:['']

    });

    this.lectureForm=this.fb.group({
      idL:[''],
      nameL:[''],
      typeL:[''],
      chapter:['']

    });
  }
  // var lecture;
  //   lecture=this.cs.getAllLecture().subscribe(data=>console.log(data));

  ngOnInit(): void {
  
    this.cs.getAllLecture().subscribe(data=>console.log(data));
    this.cs.getAllChapter().subscribe(data=>console.log(data));

    // this.vs.findVehicleById(151).subscribe(data=>console.log(data));
  }
  onFileChanged(event:any)
  {
    this.selectedFile=event.target.files[0];
    console.log(JSON.stringify(this.selectedFile));
  }
  onUpload()
  {
    // console.log(this.selectedFile);
    
    // //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
    // var uploadImageData = new FormData();
    // uploadImageData.append('pic', this.selectedFile, this.selectedFile.name);
    // console.log(uploadImageData);

    // // this.ls.sendImage(this.selectedFile).subscribe(data=>console.log(data));
    // this.ls.sendImage(uploadImageData).subscribe(data=>console.log(data));
    var formData=new FormData();
 
  //  formData.append('pic',this.selectedFile,this.selectedFile.name);
  // formData.append('name','Jag');     formData.append('courseId',chapter.courseid);
  alert(this.lectureForm.get('idL').value);
  formData.append("idL", this.lectureForm.get('idL').value);
  formData.append("nameL", this.lectureForm.get('nameL').value);
    formData.append('typeL',this.selectedFile,this.selectedFile.name);


   alert(formData);
 this.cs.addLecture(formData).subscribe(data=>console.log(data));
  }

  fnFindLecture(){
   
    var idL=this.lectureForm.controls.idL.value;
    alert(idL);
    this.cs.findLectureById(idL).subscribe(data=>{
      alert(data);
      if(data==null)
        return;
      this.lecture=data;      
      this.lectureForm.patchValue(this.lecture);
    });
  }
  
  fnAddLecture()
  {
    var lecture=this.lectureForm.value;
    this.cs.addLecture(lecture).subscribe(data=>console.log(data));
  }
  fnUpdateLecture()
  {
    var lecture=this.lectureForm.value;
    this.cs.updateLecture(lecture).subscribe(data=>console.log(data));
  }
  fnDeleteLecture()
  {
    var id=this.chapterForm.controls.id.value;
    this.cs.deleteLecture(id).subscribe(data=>console.log(data));
  }

  // -------------------------------------------below function for chapters-----------------------------------------------------------------

  fnFind()
  {
    var id=this.chapterForm.controls.id.value;
    alert(id);
    this.cs.findChapterById(id).subscribe(data=>{
      alert(data);
      console.log(data);
      if(data==null)
        return;
      this.chapter=data;      
      this.chapterForm.patchValue(this.chapter);
      // this.fnFindLecture();
    });
  }

  fnAdd()
  {
    var chapter=this.chapterForm.value;
    this.cs.addChapter(chapter).subscribe(data=>console.log(data));
    // this.fnAddLecture();
  }
  fnUpdate()
  {
    var chapter=this.chapterForm.value;
    this.cs.updateChapter(chapter).subscribe(data=>console.log(data));
    // this.fnUpdateLecture();
  }
  fnDelete()
  {
    var id=this.chapterForm.controls.id.value;
    this.cs.deleteChapter(id).subscribe(data=>console.log(data));
    // this.fnUpdateLecture();
  }

}
