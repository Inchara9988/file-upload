import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TeacherService } from '../teacher.service';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent implements OnInit {
  teacherForm:any;
  teacher:any;
  constructor(private ts:TeacherService, private fb:FormBuilder) { 
    this.teacherForm=this.fb.group({
      id:[''],
      firstName:[''],
      lastName:[''],
      email:[''],
      qualification:[''],
      password:[''],
      confirmPassword:[''],
      mobileNuber:['']

    });
  }

  ngOnInit(): void {
    this.ts.getAllTeacher().subscribe(data=>console.log(data));
    // this.vs.findVehicleById(151).subscribe(data=>console.log(data));
  }

  fnFind()
  {
    var id=this.teacherForm.controls.id.value;
    alert(id);
    this.ts.findTeacherById(id).subscribe(data=>{
      alert(data);
      if(data==null)
        return;
      this.teacher=data;      
      this.teacherForm.patchValue(this.teacher);
    });
  }

  fnAdd()
  {
    var teacher=this.teacherForm.value;
    this.ts.addTeacher(teacher).subscribe(data=>console.log(data));
  }
  fnUpdate()
  {
    var teacher=this.teacherForm.value;
    this.ts.updateTeacher(teacher).subscribe(data=>console.log(data));
  }
  fnDelete()
  {
    var id=this.teacherForm.controls.id.value;
    this.ts.deleteTeacher(id).subscribe(data=>console.log(data));
  }
}
