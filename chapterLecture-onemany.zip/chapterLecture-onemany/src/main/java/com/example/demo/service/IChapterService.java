package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Chapter;

public interface IChapterService {

	void create(Chapter chapter);

	List<Chapter> read();

	Chapter read(Integer id);

	void update(Chapter chapter);

	void delete(Chapter chapter);

}