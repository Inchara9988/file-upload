package com.example.demo.entity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "CHAPTERS")
public class Chapter {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	@Column(name = "name")
	private String name;
	 @OneToMany(mappedBy = "chapter")
	 @JsonIgnore
	 private List<Lecture> lecture;
//	@Transient
//	private SimpleDateFormat sdf;

	public Chapter() 
	{
		lecture=new ArrayList<Lecture>();
	}
public Chapter(Integer id, String name, List<Lecture> lecture) {
	this();
	this.id = id;
	this.name = name;
	this.lecture = lecture;
}
public Chapter(String name, List<Lecture> lecture) {
	this();
	this.name = name;
	this.lecture = lecture;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<Lecture> getLecture() {
	return lecture;
}
public void setLecture(List<Lecture> lecture) {
	this.lecture = lecture;
}
@Override
public String toString() {
	return "Chapter [id=" + id + ", name=" + name + ", lecture=" + lecture + "]";
}

	


	

}
