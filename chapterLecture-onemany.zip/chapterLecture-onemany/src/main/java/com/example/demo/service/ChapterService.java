package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Chapter;

import com.example.demo.repository.ChapterRepository;


@Component("chapterService")
public class ChapterService implements IChapterService  {
	@Autowired
	private ChapterRepository chapterRepository;
	
	
	@Override
	public void create(Chapter chapter)
	{
		chapterRepository.save(chapter);
	}
	
	
	
	@Override
	public List<Chapter> read()
	{
		return chapterRepository.findAll();
	}
	
	
	
	@Override
	public Chapter read(Integer id)
	{
		return chapterRepository.findById(id).get();
	}
	
	
	
	@Override
	public void update(Chapter chapter)
	{
		chapterRepository.save(chapter);
	}
	
	
	
	@Override
	public void delete(Chapter chapter)
	{
		chapterRepository.delete(chapter);
	}
	
	
//	public List<Lecture> findLectureByType(byte[] type)
//	{
//		return lectureRepository.findLectureByType(type);
//	}

}
