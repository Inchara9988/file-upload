package com.example.demo.entity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;




@Entity
@Table(name = "LECTURES")
public class Lecture {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer idL;
	@Column(name = "nameL")
	private String nameL;
	 @Lob
	private byte[] typeL;
//	@Transient
//	private SimpleDateFormat sdf;
	@ManyToOne
//	@JsonIgnore
	private Chapter chapter;
	
//	@JoinTable(name="LECTURES",joinColumns=@JoinColumn(name="lecture_id",referencedColumnName="id"),inverseJoinColumns=@JoinColumn(name="chapter_id",referencedColumnName="id"))
	public Lecture() {}

	

	public Lecture(Integer idL, String nameL, byte[] typeL, Chapter chapter) {
	super();
	this.idL = idL;
	this.nameL = nameL;
	this.typeL = typeL;
	this.chapter = chapter;
}

	public Lecture(Integer idL, String nameL, byte[] typeL) {
		super();
		this.idL = idL;
		this.nameL = nameL;
		this.typeL = typeL;
	}

	


	public Integer getIdL() {
		return idL;
	}

	public void setIdL(Integer idL) {
		this.idL = idL;
	}

	public String getNameL() {
		return nameL;
	}

	public void setNameL(String nameL) {
		this.nameL = nameL;
	}

	public byte[] getTypeL() {
		return typeL;
	}

	public void setTypeL(byte[] typeL) {
		this.typeL = typeL;
	}

	public Chapter getChapter() {
		return chapter;
	}

	public void setChapter(Chapter chapter) {
		this.chapter = chapter;
	}

	@Override
	public String toString() {
		return "Lecture [idL=" + idL + ", nameL=" + nameL + ", typeL=" + Arrays.toString(typeL) + ", chapter=" + chapter
				+ "]";
	}
	
	
	
	

}
