package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Chapter;

import com.example.demo.service.IChapterService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/chapter")
public class ChapterController {
	@Autowired
	IChapterService chapterService;
	
	@GetMapping("/")
	public List<Chapter> getAllChapters()
	{
		return chapterService.read();
	}
	
	@GetMapping("/{id}")
	public Chapter findChapterById(@PathVariable("id") Integer id)
	{
		Chapter chapter=null;
		try {
		chapter = chapterService.read(id);
		}catch(Exception ex)
		{
			return null;
		}
		return chapter;
	}
	
//	@GetMapping("/type/{type}")
//	public List<Lecture> findLecturesByType(@PathVariable("type") byte[] type)
//	{
//		return lectureService.findLectureByType(type);
//	}
//	
	@PostMapping("/")
	public void addChapter(@RequestBody Chapter chapter)
	{
		chapterService.create(chapter);
	}
	
	@PutMapping("/")
	public void updateChapter(@RequestBody Chapter chapter)
	{
		chapterService.update(chapter);
	}
	
	@DeleteMapping("/{id}")
	public void deleteChapter(@PathVariable("id") Integer id)
	{
		Chapter chapter=findChapterById(id);
		chapterService.delete(chapter);
	}
}
